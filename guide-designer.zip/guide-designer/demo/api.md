---
title: Api Usage
order: 1
---

本 Demo 演示一行文字的用法。

````jsx
import React, { Component } from 'react';
import { ConfigProvider, Button } from '@ali/deep';
import DeepGuideDesigner from '@ali/guide-designer';

// 本业务组件代码中如果有依赖任何deep下组件，请手动在此引入对应组件的style
import '@ali/deep/lib/button/style'
import '@ali/deep/lib/deep-table/style'
import '@ali/deep/lib/banner-container/style'
import '@ali/deep/lib/balloon/style'
import '@ali/deep/lib/dialog/style'
import '@ali/deep/lib/page-header/style'
import '@ali/deep/lib/message/style'
import '@ali/deep/lib/select/style'
import '@ali/deep/lib/input/style'
import '@ali/deep/lib/employee-search/style'
import '@ali/deep/lib/form/style'
import '@ali/deep/lib/collapse/style'
import '@ali/deep/lib/number-picker/style'
import '@ali/deep/lib/list/style'
import '@ali/deep/lib/illustration/style'
import '@ali/deep/lib/section-header/style'
import '@ali/deep/lib/breadcrumb/style'
import '@ali/deep/lib/step/style'

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      device: 'desktop',
      visible: false
    }
  }
  handleResize = () => {
    const width = document.documentElement.offsetWidth;
    const { device } = this.state;
    let realDevice = width < 480 ? 'phone' : width > 1024 ? 'desktop' : 'tablet';
    if (realDevice !== device) {
      this.setState({
        device: realDevice
      });
    }
  }

  handleClick = () => {
    DeepGuideDesigner.showGuideDesigner({
      scriptList: [{
  "name": "剧本名称",
  "desc": "34234234",
  "_id": "b3c80d26-a5fb-4330-b012-cbf45c0a26f7",
  "scriptType": "real",
  "props": {
    "script": [
      {
        "name": "步骤名称",
        "desc": "222",
        "scriptType": "sandbox",
        "_id": "fcbf37c9-fe4c-4643-b162-fd5885637c7d",
        "props": {
          "canvas": { "mask": true, "matchRule": "none" },
          "formation": [
            {
              "name": "test",
              "props": {
                "content": { "title": "我是引导标题", "info": "我是引导提示234324", "image": "" },
                "location": { "align": "b", "element": "selector|[id='api']+>+*+>+*+>+*+>+*|content|打开|position|size^C|9|O|C^^$0|1|2|3|4|@6|7]|5|@8|9]]" }
              }
            }
          ]
        }
      }
    ]
  }
}]
    });
  }

  componentDidMount() {
    this.handleResize();
    window.addEventListener('resize', this.handleResize, false)
    fixDevice();
  }

  render() {
    const {visible} = this.state
    return (
      <div className='my-container'>
        <ConfigProvider device={this.state.device}>
          <div>
            <Button onClick={this.handleClick}>打开</Button>
          </div>
        </ConfigProvider>
      </div>
    );
  }
}

ReactDOM.render((
  <App />
), mountNode);

function fixDevice() {
  const ua = navigator.userAgent
  const android = ua.match(/(Android);?[\s\/]+([\d.]+)?/);
  const ipad = ua.match(/(iPad).*OS\s([\d_]+)/);
  const iphone = !ipad && ua.match(/(iPhone\sOS)\s([\d_]+)/);
  if (!android && !iphone && !ipad) {
    return
  }
  const head = document.getElementsByTagName('head')[0]
  const meta = document.createElement('meta')
  const container = document.querySelector('.container')
  const myContainer = document.querySelector('.my-container')
  const customStyle = document.querySelector('.preview style')
  meta.content = 'width=device-width,minimum-scale=1.0,maximum-scale=1.0,shrink-to-fit=no,user-scalable=no'
  meta.name = 'viewport';
  head.appendChild(meta);
  if (customStyle) {
    head.appendChild(customStyle)
  }
  document.body.appendChild(myContainer)
  container.parentNode.removeChild(container)
}
````
