export default [
  {
    desc: "",
    name: "剧本名称",
    scriptType: "real",
    props: {
      script: [
        {
          _id: "asdfasg",
          desc: "sfdfadsfaf",
          name: "11111111111",
          scriptType: "sandbox",
          props: {
            formation: [
              {
                name: "test",
                props: {
                  style: { width: 200, height: 200 },
                  location: {
                    type: "absolute",
                    top: 200,
                    right: 0,
                    bottom: 0,
                    left: 100,
                    elFeature: null,
                    placement: "none",
                    arrowType: "none",
                    align: "b",
                    element: "selector|P|content|本+Demo+演示一行文字的用法。|position|size^69|2O|NS|P^^$0|1|2|3|4|@6|7]|5|@8|9]]",
                  },
                  content: { title: "标题22222", image: "", info: "内容ssssssss" },
                  advanced: {
                    btns: [
                      { title: "上一步", type: "default", _id: "child_2c78fcc6" },
                      { title: "下一步", type: "default", _id: "child_6ec7704b" },
                    ],
                  },
                },
              },
            ],
          },
        },
        {
          _id: "asdfasfafasgasg",
          desc: "sfdfadsfaf",
          name: "2222222222",
          scriptType: "sandbox",
          props: {
            formation: [
              {
                name: "card",
                _id: "material_d1f12ecb",
                props: {
                  style: { width: 200, height: 200 },
                  location: { type: "absolute", top: 200, right: 0, bottom: 0, left: 100, elFeature: null, placement: "none", arrowType: "none" },
                  content: { title: "标题", image: "", info: "内容" },
                  advanced: {
                    btns: [
                      { title: "上一步", type: "default", _id: "child_2c78fcc6" },
                      { title: "下一步", type: "default", _id: "child_6ec7704b" },
                    ],
                  },
                },
              },
            ],
          },
        },
      ],
    },
  },
];
