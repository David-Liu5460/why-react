
import Boil from '@ali/boil';
import Fry from '@ali/fryjs/index';
import { StepSchema } from "./type";
import Uri from "jsuri";

export function initMouseListener(callback: (dom: Element, elFeature: string) => void) {
  const fry = new Fry({});

  const config = {//初始化配置，详情见 API
    onSelect: (dom: Element) => {
      console.log("点击选中的dom：", dom);
      const elFeature = fry.detect(dom);
      callback(dom, elFeature);
      boil.clear();
    }
  }

  const boil = new Boil(config);

  boil.start();
}


export const jsonDownload = (content: any, fileName: string) => {
  // 创建隐藏的可下载链接
  var eleLink = document.createElement('a');
  eleLink.download = fileName;
  eleLink.style.display = 'none';
  // 字符内容转变成blob地址
  var blob = new Blob([content]);
  eleLink.href = URL.createObjectURL(blob);
  // 触发点击
  document.body.appendChild(eleLink);
  eleLink.click();
  // 然后移除
  document.body.removeChild(eleLink);
}


export function getSpm() {
  const {
    AliMonitorQueue,
    AliMonitor,
  } = window;

  let spma = '';
  let spmb = '';

  if (AliMonitorQueue && AliMonitor) {

    if (AliMonitor._runtimeConfig && typeof AliMonitor._runtimeConfig.spm === 'string') {
      const spmStr = AliMonitor._runtimeConfig.spm;
      const spmArr = spmStr.split('.');
      spma = spmArr[0] || '';
      spmb = spmArr[1] || '';
    }
  }

  return {
    spma,
    spmb,
  }
}

/**
 * 当前页面下是否展示该步骤
 * @param step 
 */
export const stepIsMatchPage =  (step: StepSchema, options: {
  spma?: string;
  spmb?: string;
}) => {
  const { canvas } = step?.props;
  if (canvas?.matchRule === 'spm') {
    const { spma, spmb } = options;
    return `${spma}.${spmb}` === canvas.spm;
  }
  if (canvas?.matchRule === 'url') {
    return isSameUrl(canvas.url, window.location.href);
  }
  return true;
}

/**
 * 当前页面下是否展示弹窗
 * @param step
 */
 export const dialogIsMatchPage = (
  schema:any,
  options?: {
    spma?: string;
    spmb?: string;
  },
) => {
  //TODO:弹窗的mathchRule暂时只支持url选项
  const { matchRule = 'url', spm, url } = schema;
  if (matchRule === 'spm') {
    const { spma, spmb } = options;
    return `${spma}.${spmb}` === spm;
  }
  if (matchRule === 'url') {
    return  isSameUrl(url, window.location.href);
  }
  return true;
};


export const isPlainObject = (value: any) => {
  if (!value || typeof value !== 'object' || ({}).toString.call(value) != '[object Object]') {
    return false;
  }
  var proto = Object.getPrototypeOf(value);
  if (proto === null) {
    return true;
  }
  var Ctor = ({}).hasOwnProperty.call(proto, 'constructor') && proto.constructor;
  return typeof Ctor == 'function' && Ctor instanceof Ctor && Function.prototype.toString.call(Ctor) === Function.prototype.toString.call(Object);
}

export const set = (obj: any, path: any, value: any) => {
  if (Object(obj) !== obj) return obj;
  if (!Array.isArray(path)) {
    path = path.toString().match(/[^.[\]]+/g) || [];
  }
  path.slice(0, -1).reduce((a: any, c: any, i: number) =>
    Object(a[c]) === a[c]
      ? a[c]
      : a[c] = Math.abs(path[i + 1]) >> 0 === +path[i + 1]
        ? []
        : {},
    obj)[path[path.length - 1]] = value;
  return obj;
};

const checkMatchHref = (triggerContent: string, href: string) => {
  const reg = new RegExp(triggerContent.replace(/([\/\?\.])/g, '\\$1').replace(/\*/g, '.*'));
  return reg.test(href)
};

export const isSameUrl = (url: string, targetUrl: string) => {
  if (checkMatchHref(url, targetUrl)) {
    return true;
  }
  const uri = new Uri(url);
  const targetUri = new Uri(targetUrl);
  // path存在才比较是否 path 一致
  if ((uri.path() && uri.path() !== '/') && uri.path() !== targetUri.path()) {
    return false;
  }
  // 锚点一致
  if (uri.anchor() !== targetUri.anchor()) {
    return false
  }
  // query一致
  const params: any[] = (uri as any).queryPairs;
  let sameParams = true;
  params.forEach(([key, value]) => {
    if (targetUri.getQueryParamValue(key) !== value) {
      sameParams = false;
    }
  })

  return sameParams;
}