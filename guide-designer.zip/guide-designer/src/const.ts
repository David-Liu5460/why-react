// 气泡位置
export const alignEnum = [{
  text: '上', value: 't'
}, {
  text: '右', value: 'r'
}, {
  text: '下', value: 'b'
}, {
  text: '左', value: 'l'
}, {
  text: '上左', value: 'tl'
}, {
  text: '上右', value: 'tr'
}, {
  text: '下左', value: 'bl'
}, {
  text: '下右', value: 'br'
}, {
  text: '左上', value: 'lt'
}, {
  text: '左下', value: 'lb'
}, {
  text: '右上', value: 'rt'
}, {
  text: '右下', value: 'rb'
}]


export const matchRuleEnum = [{
  text: '不匹配', value: 'none'
}, {
  text: '页面SPM码', value: 'spm'
}, {
  text: '页面地址', value: 'url'
}]

// 可视化埋点 feature
export const feature = 'helpGuide';