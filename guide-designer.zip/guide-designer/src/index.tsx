import GuideDesigner from "./designer";

import { showScriptGuide, autoFindGuideAndShow, findCurrentPageGuide, showStepsGuide } from "./player/showGuide";
import { showGuideDesigner, showFuyaoGuideDesigner } from './designer/api';
import { getLoginUserInfo } from './service';

GuideDesigner.showGuideDesigner = showGuideDesigner;
GuideDesigner.showFuyaoGuideDesigner = showFuyaoGuideDesigner;
GuideDesigner.showScriptGuide = showScriptGuide;
GuideDesigner.showStepsGuide = showStepsGuide;
GuideDesigner.autoFindGuideAndShow = autoFindGuideAndShow;
GuideDesigner.getLoginUserInfo = getLoginUserInfo;
GuideDesigner.findCurrentPageGuide = findCurrentPageGuide;

(window as any).GuideDesigner = GuideDesigner;


export {
  showGuideDesigner,
  showFuyaoGuideDesigner,
  showScriptGuide,
  getLoginUserInfo,
  autoFindGuideAndShow,
  findCurrentPageGuide,
  showStepsGuide
};
export default GuideDesigner;

