export default class GuidePlayer {
  options: any;

  constructor(options) {
    this.options = {
      ...options
    }
  }
}