import React from "react";
import ReactDOM from 'react-dom';
import Fry from "@ali/fryjs/index";
import showUserGuide, { renderContainer, guideRef } from "../component/GuideApi";
import addHistoryListener from "@issimo/add-history-listener";
import DialogGuide from "@ali/vc-fuyao-dialog-guide";
import { getSpm, stepIsMatchPage, dialogIsMatchPage } from "../help";
import { StepSchema, ScriptSchema, Content } from "../types/index";
import zhCn from "../locale/zh-cn";
import { feature } from "../const";

export interface DeepUserGuideType {
  element: string;
  title: string;
  content: React.ReactChild;
  ballonAlign: string;
  mode: "cover" | "point";
  icon: any;
}

export interface showScriptGuideOptions {
  shouldPreventDuplicated?: boolean;
  cacheStrategy?: "localStorage" | "cookie";
  deepPrefix?: string;
  autolog?: Function;
  theme?: string;
  className?: string;
}

export const transferStep = (step: StepSchema): DeepUserGuideType[] => {
  const formation = step?.props?.formation || [];
  const mode = step?.props?.canvas?.mask ? "cover" : "point";
  return formation.map((item) => {
    const { location, content, parent } = item.props;
    let element: any = location?.element || null;
    element = findDomExisted(element);

    return {
      content: getDisplayContent(content),
      title: getVariable(content?.title),
      icon: null,
      mode: mode,
      ballonAlign: location?.align,
      element: element,
      parent: getParent(parent),
    };
  });
};

export const getParent = (parent: string) => {
  if (parent) {
    return parent;
  }
  const keyName = "[class$='-shell-sub-main']";
  if (document.querySelector(keyName)) {
    return keyName;
  }
  return parent;
}

/**
 * 引导内容处理
 * @param content
 */
export const getDisplayContent = (content: Content) => {
  const { info, image, videoUrl } = content;
  // 播放视频
  if (videoUrl) {
    return (
      <video width={"400px"} src={getVariable(videoUrl)} preload="auto" autoPlay={true}>
        您的浏览器不支持视频播放
      </video>
    );
  }
  if (!image) {
    return getVariable(content.info);
  }
  return (
    <div>
      <img
        style={{
          width: "100%",
        }}
        src={getVariable(image)}
      ></img>
      <div>{getVariable(info)}</div>
    </div>
  );
};
/**
 * 参数支持变量
 * @param key 
 */
export const getVariable = (key: string) => {
  if (!key) {
    return ''
  }
  // 支持${}正则
  const patt = /^(['"]?)\${(.*)}\1$/;
  if (!patt.test(key)) {
    return key;
  }
  try {
    const value = key.replace(patt, '$2');
    const compiled = `with($scope || {}) {return ${value}}`;
    const fn = new Function('$scope', 'args', compiled);
    return `${fn.call(undefined)}`;
  } catch (err) {
    return key
  }
}

export const getLocaleObj = (locale?: { [key: string]: string }) => {
  if (!locale) {
    return undefined;
  }
  const result = Object.keys(locale).reduce((obj, keyName, index) => {
    obj[keyName] = getVariable(locale[keyName]);
    return obj
  }, {} as any);
  return {
    ...zhCn,
    ...result
  }
}

export const showScriptGuide = async (schema: ScriptSchema | any, options: showScriptGuideOptions, list?: any[]) => {
  // shcema下有props，是引导的schema
  const { shouldPreventDuplicated, deepPrefix = 'deep-', theme = 'blue' } = options;

  const className = `${deepPrefix}${theme}`;
  options.className = className
  // 步骤引导
  if (schema.props) {
    return showStepsGuide(schema, options);
  }

  // 弹窗引导
  const { guideId, showGuide, id } = schema;
  const data = list.find(item => `${item.id}` === `${guideId}` || `${item._id}` === `${guideId}`);

  if (shouldPreventDuplicated && !detectWillShow(schema, 'dialog-guide')) {
    return;
  }
  return new Promise((resolve) => {
    const overlayProps = { className };

    DialogGuide.show({ ...schema, deepPrefix, overlayProps }, () => {
      if (shouldPreventDuplicated) {
        localStorage.setItem(`dialog-guide-${id}`, "true");
      }
      if (showGuide && guideId) {
        resolve(showStepsGuide(data, options))
      } else {
        resolve(undefined);
      }
    })
  })
};

export const showStepsGuide = (data: ScriptSchema, options: showScriptGuideOptions) => {
  const id = data?.id || data?._id;
  const { shouldPreventDuplicated = false, cacheStrategy = "localStorage", deepPrefix, autolog = () => { }, className } = options;
  // 防重复并且之前已经播放过，不再播放
  if (shouldPreventDuplicated && !detectWillShow(data)) {
    return;
  }

  const steps = data?.props?.script || [];

  const ignorePassBtn = data?.props?.ignorePassBtn;

  const locale = getLocaleObj(data?.props?.locale);

  // schema转换并过滤些无效的配置
  const config: DeepUserGuideType[] = steps
    .reduce((result: any, step: any, index: any) => {
      const itemConfig = transferStep(step);
      return result.concat(itemConfig);
    }, [])
    .filter((item: DeepUserGuideType) => {
      return !!item.element;
    });
  // 校验config是否丢失，丢失的话上报
  if (steps.length !== config.length) {
    // TODO: 异常上报
    console.log("部分schema不生效");
  }
  if (config.length === 0) {
    console.log("当前配置在该页面下不生效！");
    return Promise.reject("没有读取到配置");
  }

  const dom = config[0].element;
  const key = `user-guide-script-${id}`;

  return showUserGuide(config, false, undefined, { deepPrefix, ignorePassBtn, prefix: deepPrefix, locale, className })
    .onFinish(() => {
      shouldPreventDuplicated && localStorage.setItem(key, "true");
      // 打点
      autolog(dom, "fyHelpGuide_finish", "帮助引导：步骤完整执行", { feature });
    })
    .onPrev(() => {
      autolog(dom, "fyHelpGuide_prev", "帮助引导：上一步", { feature });
    })
    .onNext((currentStep: any) => {
      autolog(dom, "fyHelpGuide_stepId", `帮助引导-步骤点击：${currentStep}`, { feature });
    })
    .onDismiss(() => {
      autolog(dom, "fyHelpGuide_skip", "帮助引导：跳过", { feature });
      shouldPreventDuplicated && localStorage.setItem(key, "true");
    });
}

// 预览时添加引导
export const showScriptGuideInPreview = (data: ScriptSchema) => {
  const steps = data?.props?.script || [];

  const locale = getLocaleObj(data?.props?.locale);

  const config: DeepUserGuideType[] = steps.reduce((result, step, index) => {
    const itemConfig = transferStep(step);
    return result.concat(itemConfig);
  }, []);
  showUserGuide(config, false, undefined, {
    locale
  });
};


export const findCurrentPageGuide = (list: any[]) => {
  const { spma, spmb } = getSpm();
  // 根据剧本的第一个步骤是否在当前页面
  const hitSchema = list.filter((schema) => {
    const { guideType } = schema;

    if (guideType === 'common') {
      const steps = schema?.props?.script || [];
      const condition = (schema?.props as any)?.condition;
      const firstStep = steps[0];

      if (!firstStep) {
        return false;
      }

      // 根据页面的query参数去判断,如果query中存在，则返回
      if (condition && condition?.type === "query") {
        const { value } = condition;
        const isExist = window.location.search.indexOf(value) > -1;
        return isExist;
      }

      // 该步骤对应的dom存在于页面上
      const isMatchPage = stepIsMatchPage(firstStep, { spma, spmb });
      if (!isMatchPage) {
        return false;
      }
    } else if (guideType === 'dialog') {
      const isMatchPage = dialogIsMatchPage(schema, { spma, spmb })
      if (!isMatchPage) {
        return false;
      }
    }
    return true;
  });
  return hitSchema;
}

// 自动发现引导并且执行
export const autoFindGuideAndShow = async (
  list: any[] = [],
  options: showScriptGuideOptions = {
    shouldPreventDuplicated: true,
    cacheStrategy: "localStorage",
  },
) => {
  // 异步操作放到外面，获取页面的spma、spmb码
  const findGuideAndPlay = async () => {
    // 异步操作放到外面，获取页面的spma、spmb码
    try {
      // 根据剧本的第一个步骤是否在当前页面
      const matchSchema = findCurrentPageGuide(list);

      const hitSchema = matchSchema.find(item => item.guideStatus === 'autoplay');

      // FIXME: 这里如果有多个剧本时，都是不匹配就会有问题
      if (!hitSchema) {
        console.log("未发现命中的引导配置，请联系管理员！");
        return;
      }

      if (hitSchema.guideType === 'common') {
        // 确定第一个步骤中的元素存在时才去执行引导
        const waitWhichStep = hitSchema?.props?.waitStep || 0;
        const hitSchemaFirstStep = hitSchema?.props?.script[waitWhichStep];
        const domIsExisted = await waitDomIsExisted(hitSchemaFirstStep);
        if (!domIsExisted) {
          return;
        }
      }
      showScriptGuide(hitSchema, options, list);
    } catch (error) {
      console.log('fuyao', error.message);
    }
  };

  // 默认执行一次
  findGuideAndPlay();
  // 监听路由变化并且播放
  addHistoryListener(() => {
    // FIXME: 先改成页面切换时删除现在的引导，待后续支持跨页引导时修改此处
    guideRef?.hide();
    setTimeout(() => {
      if (renderContainer) {
        ReactDOM.unmountComponentAtNode(renderContainer);
      }
      findGuideAndPlay();
    }, 200)
  });
};

/**
 * 检测是否展示
 * @param steps
 */
const detectWillShow = (data: ScriptSchema, prefix: string = 'user-guide-script') => {
  const id = data?.id || data?._id;
  if (id) {
    // 防重复提示机制，以 user-guide-script.id 为 key 存储入 localStorage
    const key = `${prefix}-${id}`;
    return !localStorage.getItem(key);
  }
  return true;
};

const findDomExisted = (element: string) => {
  let dom;
  try {
    dom = new Fry({}).query(element);
  } catch (err) {
    try {
      dom = document.querySelector(element) || undefined;
    } catch (err) { }
  }
  return dom;
};

/**
 * 等待第一个step中的element对应的dom出现
 * @param step
 */
export const waitDomIsExisted = async (step: StepSchema) => {
  const formation = step?.props?.formation || [];
  const element = formation[0]?.props.location.element;
  if (!element) {
    return;
  }
  return new Promise((resolve, reject) => {
    const dom = findDomExisted(element);
    // 能检测到dom直接返回
    if (dom) {
      resolve(dom);
    }
    // 定时间隔检测dom是否存在
    var interval = setInterval(() => {
      var dom = findDomExisted(element);
      if (dom) {
        resolve(dom);
        clearInterval(interval);
      }
    }, 500);
    // 超过一分钟就取消interval
    setTimeout(() => {
      if (interval) {
        clearInterval(interval);
        // 超时
        console.log(`引导配置dom${element}不存在，请确认配置是否正确！`);
        resolve();
      }
    }, 1000 * 30);
  });
};
