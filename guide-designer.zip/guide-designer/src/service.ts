import axios from "axios";
import jsonp from "jsonp";
import queryString from "query-string";
import { FuyaoSchemaResponse } from "./type";

interface UserType {
  empId: string;
  lastName: string;
  nickName: string;
  realmId: number;
  userId: number;
}

interface IUrlMap {
  [key: string]: {
    [key: string]: {
      [key: string]: string;
    };
  };
}
const urlMap: IUrlMap = {
  inner: {
    develop: {
      fuyao: "https://fuyao.alibaba.net",
      login: "https://login.alibaba-inc.com",
    },
    pre: {
      fuyao: "https://pre-fuyao.alibaba-inc.com",
      login: "https://login.alibaba-inc.com",
    },
    product: {
      fuyao: "https://fuyao.alibaba-inc.com",
      login: "https://login.alibaba-inc.com",
    },
  },
  vpc: {
    develop: {
      fuyao: "https://fuyao.alibaba.net",
      login: "https://login.alibaba-inc.com",
    },
    pre: {
      fuyao: "https://pre-fuyao-vpc.alibaba-inc.com",
      login: "https://login.alibaba-inc.com",
    },
    product: {
      fuyao: "https://fuyao.alibaba.com",
      login: "https://login.alibaba-inc.com",
    },
  },
};

let env = "product";
export let envType = "inner";

export const setEnv = (e: "product" | "pre" | "develop" = "develop") => {
  env = e;
};

export const setEnvType = (e: "inner" | "vpc" = "inner") => {
  envType = e;
};

export const getHost = (name: string) => {
  return urlMap[envType][env][name];
};

// 加载配置详情（外部业务系统使用）
export const getSchemaListInFuyao = (
  params: {
    appCode: string;
    path?: string;
    guideType?: string;
  },
  env?: string
): Promise<FuyaoSchemaResponse[]> => {
  const param = queryString.stringify(params);
  return new Promise((resolve, reject) => {
    jsonp(
      `${getHost("fuyao")}/api/fuyao/open/guide/load.json?${param}`,
      {
        prefix: "__guideDesigner",
      },
      (err: any, resp: any) => {
        const { success, content = [] } = resp;
        if (!success || err) {
          reject(err);
          return;
        }
        resolve(content);
      }
    );
  });
};

// 扶摇单条剧本保存
export const saveSchemaDataJsonpInFuyao = (
  params: {
    id?: string;
    appCode: string;
    schema: string;
    workNo?: string;
    guideType?: string;
  },
  env?: string
): Promise<any> => {
  const param = queryString.stringify(params);
  return new Promise((resolve, reject) => {
    jsonp(
      `${getHost("fuyao")}/api/fuyao/open/guide/save.json?${param}`,
      {
        prefix: "__guideDesigner",
      },
      (err: any, resp: any) => {
        const { success, content = [] } = resp;
        if (!success || err) {
          reject(err);
          return;
        }
        resolve(content);
      }
    );
  });
};

// 扶摇单条剧本删除
export const deleteSchemaDataInFuyao = (
  params: {
    id: string;
  },
  env?: string
) => {
  const param = queryString.stringify(params);
  return new Promise((resolve, reject) => {
    jsonp(
      `${getHost("fuyao")}/api/fuyao/open/guide/delete.json?${param}`,
      {
        prefix: "__guideDesigner",
      },
      (err: any, resp: any) => {
        const { success, content = [] } = resp;
        if (!success || err) {
          reject(err);
          return;
        }
        resolve(content);
      }
    );
  });
};

// 获取登录用户信息
export const getLoginUserInfo = (env: "product" | "pre" | "develop" = "product"): Promise<UserType> => {
  return new Promise((resolve, reject) => {
    jsonp(
      `${urlMap[env]["login"]}/rpc/userQuery/getLoginedUser.jsonp`,
      {
        prefix: "__guideDesigner",
      },
      (err: any, resp: any) => {
        const { hasError, content = [] } = resp;
        if (hasError || err) {
          reject(err);
          return;
        }
        resolve(content);
      }
    );
  });
  // https://login.alibaba-inc.com/rpc/userQuery/getLoginedUser.jsonp
};
