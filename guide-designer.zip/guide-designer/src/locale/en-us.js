export default {
  locale: "en-us",
  pass: "Pass",
  next: "Next",
  prev: "Previous",
  finish: "OK",
};
