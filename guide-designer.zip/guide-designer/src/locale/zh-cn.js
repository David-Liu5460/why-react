export default {
  locale: "zh-en",
  pass: "跳过引导",
  next: "下一步",
  prev: "上一步",
  finish: "完成",
};
