
import set from "lodash.set";

export const formDataFormatIn = (value: any, result: any = {}, prefix?: string) => {
  if (!(Object.prototype.toString.call(value) === '[object Object]')) {
    return result;
  }
  Object.keys(value).forEach(keyName => {
    const item = value[keyName];
    const realPath = prefix ? `${prefix}.${keyName}` : keyName;

    if (Object.prototype.toString.call(item) === '[object Object]') {
      formDataFormatIn(item, result, realPath);
    } else {
      result[realPath] = item;
    }
  })
  return result;
}

export const formDataFormatOut = (value: any) => {
  const result = {};
  Object.keys(value).forEach(keyName => {
    const item = value[keyName];
    set(result, keyName, item);
  })
  return result;
}
