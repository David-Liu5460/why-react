import React from "react";
import { ConfigProvider, Drawer, Icon, Breadcrumb, SectionHeader } from "@ali/deep";
import classnames from "classnames";
import zhCN from "../locale/zh-cn";
import EditDetail from "./pages/EditDetail";
import ScriptList from "./pages/ScriptList";
import StepList from "./pages/StepList";
import ScriptDetail from "./pages/ScriptDetail";
import { ScriptSchema, StepSchema, IDeepGuideDesignerProps, IDeepGuideDesignerState } from "../types/index";

import '@alife/theme-254/dist/next.js';
import '@ali/deep-user-guide/lib/style';
import '@ali/deep-page-section/lib/style';

class DeepGuideDesigner extends React.Component<Partial<IDeepGuideDesignerProps>, IDeepGuideDesignerState> {
  langs: any;

  static displayName = "DeepGuideDesigner";

  static defaultProps: IDeepGuideDesignerProps = {
    deepPrefix: "deep-",
    device: "desktop",
    locale: zhCN,
    scriptList: [],
    onScriptListChange: (scriptList: ScriptSchema[]) => { },
    onScriptItemSubmit: (scriptList: ScriptSchema) => { },
    onScriptItemDelete: (id: string) => { },
  };

  state: IDeepGuideDesignerState = {
    visible: this.props.visible || false,
    activeTab: "script",
    scriptList: this.props.scriptList || [],
    currentScriptIndex: undefined,
    currentStep: undefined,
    drawerPlacement: "right",
  };

  constructor(props: Partial<IDeepGuideDesignerProps>) {
    super(props);
    this.langs = props.locale;
  }

  componentDidMount() {
    const { visible } = this.props;
    if (visible) {
      document.body.classList.add('guide-designer-body-helper');
    } else {
      document.body.classList.remove('guide-designer-body-helper');
    }
  }

  componentWillUnmount() {
    document.body.classList.remove('guide-designer-body-helper');
  }

  componentWillReceiveProps(nextProps: IDeepGuideDesignerProps) {
    if (nextProps.visible === true) {
      document.body.classList.add('guide-designer-body-helper');
    } else {
      document.body.classList.remove('guide-designer-body-helper');
    }
    const newState: any = {
      visible: nextProps.visible,
    }

    if (nextProps.scriptList !== this.state.scriptList) {
      newState.scriptList = nextProps.scriptList;
    }

    this.setState(newState);
  }

  // scriptList内容监听
  notifyScriptChange = (type: "change" | 'add' | 'delete') => {
    const { onScriptListChange } = this.props;
    const { scriptList } = this.state
    onScriptListChange(scriptList, type);
  }

  // 切换抽屉的位置，左右切换
  toggleDrawerDirection = () => {
    const { drawerPlacement } = this.state;
    this.setState({
      drawerPlacement: drawerPlacement === 'left' ? 'right' : 'left'
    })
  }

  // 抽屉关闭
  onClose = () => {
    // TODO: 提交时check是否有变动
    this.setState({
      visible: false,
      activeTab: "script",
      currentScriptIndex: undefined,
      currentStep: undefined,
      scriptList: []
    });
  };

  // 回到剧本列表
  onBackScriptList = () => {
    this.setState({
      activeTab: "script",
      currentScriptIndex: undefined
    })
  }

  // 回到步骤列表
  onBackStepList = () => {
    this.setState({
      activeTab: "step",
      currentStep: undefined
    })
  }

  // 剧本查看
  onScriptView = (data: ScriptSchema, index: number) => {
    this.setState({
      activeTab: 'step',
      currentScriptIndex: index
    })
  }

  // 剧本编辑
  onScriptEdit = (index?: number) => {
    this.setState({
      activeTab: 'scriptDetail',
      currentScriptIndex: index
    })
  }

  // 剧本删除
  onScriptDelete = (data: ScriptSchema) => {
    const { scriptList } = this.state;
    const { onScriptItemDelete } = this.props;
    const index = scriptList.findIndex(script => script._id === data._id);
    const deleteScript = scriptList[index];
    if (index !== -1) {
      scriptList.splice(index, 1);
    }
    this.setState({
      scriptList: [...scriptList]
    }, () => {
      this.notifyScriptChange('delete');
      // FIXME: id从后端生。
      const { id } = deleteScript;
      onScriptItemDelete(id);
    })
  }

  // 步骤编辑
  onStepEdit = (step: StepSchema) => {
    this.setState({
      activeTab: 'content',
      currentStep: step
    })
  }

  // 单条剧本的变化
  onScriptChange = (script: ScriptSchema) => {
    const { currentScriptIndex, scriptList } = this.state
    const newScriptList = scriptList.slice();
    if (typeof currentScriptIndex === 'undefined') {
      newScriptList.unshift(script);
      this.setState({
        scriptList: newScriptList,
      }, () => {
        this.notifyScriptChange('add');
        // 新增完直接到步骤列表
        // this.onScriptView(undefined, 0);
      })
    } else {
      newScriptList.splice(currentScriptIndex, 1, script);
      this.setState({
        scriptList: newScriptList,
      }, () => {
        this.notifyScriptChange('change')
      })
    }
  }

  // 步骤内容提交
  onStepContentSubmit = (values: StepSchema) => {
    const { currentScriptIndex, scriptList } = this.state

    const currentScript = scriptList[currentScriptIndex];

    const { script } = currentScript.props;

    const currentStepIndex = script.findIndex(step => step._id === values._id);
    const newScripts = script.slice();
    newScripts.splice(currentStepIndex, 1, values);

    const newCurrentScript = {
      ...currentScript,
      props: {
        ...currentScript.props,
        script: newScripts
      }
    };

    const newScriptList = scriptList.slice();
    newScriptList.splice(currentScriptIndex, 1, newCurrentScript);

    this.setState({
      scriptList: newScriptList,
      currentStep: values,
      activeTab: 'step',
    }, () => {
      this.notifyScriptChange('change')
    })
  }

  /**
   * 渲染面包屑
   */
  renderBreadCrumb() {
    const { activeTab } = this.state;

    if (activeTab === 'content') {
      return <Breadcrumb>
        <Breadcrumb.Item link="javascript:void(0);" onClick={this.onBackScriptList}>首页</Breadcrumb.Item>
        <Breadcrumb.Item link="javascript:void(0);" onClick={this.onBackStepList}>步骤列表</Breadcrumb.Item>
        <Breadcrumb.Item >步骤详情</Breadcrumb.Item>
      </Breadcrumb>
    }
    if (activeTab === 'step') {
      return <Breadcrumb>
        <Breadcrumb.Item link="javascript:void(0);" onClick={this.onBackScriptList}>首页</Breadcrumb.Item>
        <Breadcrumb.Item>剧本详情</Breadcrumb.Item>
      </Breadcrumb>
    }
    return <Breadcrumb>
      <Breadcrumb.Item>首页</Breadcrumb.Item>
    </Breadcrumb>
  }

  renderHeader() {
    const { activeTab } = this.state;
    const activeTabTitleMap = {
      "script": "步骤引导配置",
      'step': "步骤配置",
      "content": "步骤详情",
      "scriptDetail": "剧本信息"
    }
    return (
      <div className="guide-designer-header" >
        <div className="guide-designer-crumb">
          {this.renderBreadCrumb()}
        </div>
        < SectionHeader title={activeTabTitleMap[activeTab]} />
        <div className="guide-designer-close" onClick={this.onClose}>
          <Icon type="close" />
        </div>
      </div>
    )
  }
  renderContent() {
    const { activeTab, scriptList, currentScriptIndex, currentStep } = this.state;
    const { onScriptItemSubmit } = this.props;
    const currentScript = typeof currentScriptIndex === 'undefined' ? undefined : scriptList[currentScriptIndex];
    return (
      <div className="guide-designer-content">
        {activeTab === 'script' && <ScriptList data={scriptList} onEdit={this.onScriptEdit} onView={this.onScriptView} onDelete={this.onScriptDelete} onScriptItemSubmit={onScriptItemSubmit} onClose={this.onClose} />}
        {activeTab === 'scriptDetail' && <ScriptDetail data={currentScript} onBack={this.onBackScriptList} onSubmit={this.onScriptChange} />}
        {activeTab === 'step' && <StepList data={currentScript} onEdit={this.onStepEdit} onClose={this.onClose} onBack={this.onBackScriptList} onChange={this.onScriptChange} />}
        {activeTab === 'content' && <EditDetail data={currentStep} onClose={this.onClose} onSubmit={this.onStepContentSubmit} onBack={this.onBackStepList} />}
      </div>
    )
  }

  render() {
    const { drawerPlacement } = this.state;
    return (
      <ConfigProvider
      // prefix="guide-"
      >
        <Drawer
          width={400}
          placement={drawerPlacement}
          bodyStyle={{
            padding: '0px',
            position: 'relative'
          }} closeable={false} hasMask={false} visible={this.state.visible}>
          {/* placement切换按钮 */}
          <div className={classnames("guide-designer-toggle-direction", `guide-designer-toggle-direction-${drawerPlacement}`)} onClick={this.toggleDrawerDirection}>
            <Icon size='small' title={"位置切换"} type={drawerPlacement === "left" ? "menu-expand" : "menu-collapse"} />
          </div>
          <div className="guide-designer-body">
            {this.renderHeader()}
            {this.renderContent()}
          </div>
        </Drawer>
      </ConfigProvider>
    );
  }
}


export default ConfigProvider.config(DeepGuideDesigner, {
  prefix: "guide-"
});
