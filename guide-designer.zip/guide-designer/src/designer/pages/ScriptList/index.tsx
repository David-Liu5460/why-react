import * as React from "react";
import ScriptListItem from "./ScriptListItem";
import { Button, Form, Illustration, Icon } from "@ali/deep";
import { ScriptSchema } from "../../../types/index";

import "./index.scss";

interface ScriptListProps {
  onView: (data: ScriptSchema, index: number) => void;
  onDelete: (data: ScriptSchema) => void;
  onEdit: (index?: number) => void;
  onScriptItemSubmit: (scriptList: ScriptSchema) => {},
  onClose: () => void;
  data: ScriptSchema[];
}

export default class ScriptList extends React.Component<ScriptListProps, any> {

  static displayName = 'ScriptList';

  formRef: typeof Form = null;
  render() {
    const { onView, onDelete, onScriptItemSubmit, data = [], onEdit } = this.props
    return (
      <div className="guide-designer-content-body guide-designer-script-list">
        <div className="guide-designer-script-action">
          <Button type="secondary" size="small" onClick={() => { onEdit(undefined) }} ><Icon type="add" />添加剧本</Button>
        </div>
        <div className="guide-designer-script-list-content">
          {
            data.length > 0
              ? data.map((item: any, index: number) => {
                return (
                  <ScriptListItem data={item} index={index} onView={(data: ScriptSchema) => onView(data, index)} onDelete={onDelete} onSubmit={onScriptItemSubmit} onEdit={onEdit} />
                )
              })
              : <Illustration style={{
                marginTop: '60px'
              }} type="empty" size="small" link="#" content="当前应用下暂无任何剧本" />
          }
        </div>
      </div>
    )
  }
}