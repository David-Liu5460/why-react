import React from "react";
import { Button, Balloon, Icon, Message } from "@ali/deep";
import classnames from "classnames";
import { jsonDownload } from "../../../help";
import { showScriptGuideInPreview } from "../../../player/showGuide";
import PageSection from "@ali/deep-page-section";
import { envType } from "../../../service";

import { ScriptSchema } from "../../../types/index";

interface ScriptListItemProps {
  data: ScriptSchema;
  index: number;
  className?: string;
  onView: (data: ScriptSchema, index: number) => void;
  onSubmit: (data: ScriptSchema) => void;
  onDelete: (data: ScriptSchema) => void;
  onEdit: (index?: number) => void;
}

export default class ScriptListItem extends React.Component<ScriptListItemProps> {
  constructor(props: any) {
    super(props);
  }

  onClickExport = () => {
    const { data } = this.props;
    jsonDownload(JSON.stringify(data), '剧本.json')
  }

  onClickSyncService = () => {

  }

  onClickSubmit = () => {
    const { data, onSubmit } = this.props;
    if (envType !== "inner") {
      Message.warning('因安全策略，外部版不支持直接上传，请到扶摇后台导入上传！')
      return;
    }

    onSubmit(data);
  }

  onClickPrev = () => {
    const data: ScriptSchema = this.props.data;
    showScriptGuideInPreview(data);
  }

  renderDelete() {
    const { onDelete, data } = this.props;
    const deleteButton = <Button text >删除</Button>
    return (
      <Balloon align="bl" triggerType="click" trigger={deleteButton} closable={false} showButton onOk={() => onDelete(data)} popupContainer={(trigger: any) => trigger.parentNode} >
        确认删除么?
      </Balloon>
    )
  }

  renderNormal() {
    const { data, onView, index } = this.props;
    const { name, desc } = data;

    const stepLength = ((data as ScriptSchema)?.props?.script || []).length;
    return (
      <div className="guide-designer-script-item">
        <div className="guide-designer-script-item-media">
          <span className="guide-designer-script-item-media-index">{index + 1}</span>
        </div>
        <div className="guide-designer-script-item-content">
          <div className="guide-designer-script-item-content-title">{name} {stepLength > 0 ? `（共${stepLength}步）` : null}</div>
          <div className="guide-designer-script-item-content-desc">{desc}</div>
          <div className="guide-designer-script-item-content-action">
            <Button text onClick={this.onClickPrev}>预览</Button>
            <Button text onClick={() => onView(data, index)}>查看</Button>
            {/* <Button text onClick={this.onClickExport}>导出</Button> */}
            <Button text onClick={this.onClickSubmit}>同步</Button>
            {this.renderDelete()}
          </div>
        </div>
      </div>
    )
  }

  onDelete = () => {
    const { onDelete, data } = this.props;
    onDelete(data);
  }

  onEdit = () => {
    const { onEdit, index } = this.props;
    onEdit(index);
  }

  onView = () => {
    const { onView, data, index } = this.props;
    onView(data, index);
  }

  renderExtra() {

    return (
      <>
        <Icon title="查看" type="view-detail" size='small' onClick={this.onView} />
        <Icon title="编辑" type="edit" size='small' onClick={this.onEdit} />
        <Icon title="预览"  type="eye" size='small' onClick={this.onClickPrev}/>
        <Icon title="上传/同步" type="upload" size='small' onClick={this.onClickSubmit}/>
        <Icon title="导出"  type="download" size='small' onClick={this.onClickExport}/>
        <Icon title="删除" type="ashbin" size='small' onClick={this.onDelete} />
      </>
    )
  }

  render() {
    const { className, data } = this.props;
    const { name, desc } = data;
    return (
      <div className={classnames('guide-designer-list-item', className)}>
        <PageSection
          className="page-section-demo-box"
          title={name}
          tooltip={desc}
          extra={this.renderExtra()}
          withPadding={false}
        >
          {/* <div className="page-section-demo-content">这里是卡片内容</div> */}
        </PageSection>
      </div>
    )
  }
}

