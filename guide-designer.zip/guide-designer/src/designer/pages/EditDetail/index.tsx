import * as React from "react";
import { Form, TextField, SelectField, Button, SectionHeader, SwitchField } from "@ali/deep";
import { set, isPlainObject } from "../../../help";
import { alignEnum, matchRuleEnum } from "../../../const";
import { StepSchema } from "../../../types/index";
import { transferStep } from "../../../player/showGuide";
import GuidePreview from "../../../component/GuidePreview";

import SelectDomField from "../../../component/SelectDomField";
import InputUrlField from "../../../component/InputUrlField";

import "./index.scss";

interface EditDetailProps {
  onClose: () => void;
  data?: StepSchema;
  onSubmit: (values: any) => void;
  onBack: () => void;
}

interface EditDetailState {
  value: any;
  guideVisible: boolean;
}

export default class EditDetail extends React.Component<EditDetailProps, EditDetailState> {

  static displayName = 'EditDetail';

  editForm: any;

  constructor(props: EditDetailProps) {
    super(props);
    this.state = {
      value: this.formatIn(props.data),
      guideVisible: false,
    }
  }

  componentDidMount() {
    this.setState({
      guideVisible: true
    })
  }

  componentWillUnmount() {
    this.setState({
      guideVisible: false
    })
  }

  componentWillReceiveProps(nextProps: EditDetailProps) {
    this.setState({
      value: this.formatIn(nextProps.data)
    })
  }

  // onChange 联动场景使用
  onChange = (values: any, item: any) => {
    this.setState({
      value: values,
    });
  }

  formatIn = (value: StepSchema) => {
    const values: any = value?.props?.formation[0].props;
    const canvas: any = value?.props?.canvas || {};
    const result: any = {}
    // 数据转换
    Object.keys(values).map(keyName => {
      if (!values[keyName] || typeof values[keyName] === 'string') {
        result[keyName] = values[keyName];
      }
      if (isPlainObject(values[keyName])) {
        Object.keys(values[keyName]).map(subKeyName => {
          result[`${keyName}.${subKeyName}`] = values[keyName][subKeyName];
        })
      }
    })
    Object.keys(canvas).map(keyName => {
      if (isPlainObject(canvas[keyName])) {
        Object.keys(canvas[keyName]).map(subKeyName => {
          result[`canvas.${keyName}.${subKeyName}`] = canvas[keyName][subKeyName];
        })
      } else {
        result[`canvas.${keyName}`] = canvas[keyName];
      }
    })
    return result;
  }

  formatOut = (values: any): StepSchema => {
    const { data } = this.props;
    if (!values) {
      return {
        ...data
      }
    }
    const result: any = {}
    const canvas: any = {};
    Object.keys(values).map(keyName => {
      if (keyName.startsWith('canvas.')) {
        const newKeyName = keyName.slice(7)
        set(canvas, newKeyName, values[keyName]);
      } else {
        set(result, keyName, values[keyName] || undefined);
      }
    })
    return {
      ...data,
      props: {
        canvas,
        formation: [{
          name: "test",
          props: result
        }]
      }
    }
  }

  onBack = () => {
    const { onBack } = this.props;
    this.setState({
      guideVisible: false
    }, () => {
      setTimeout(() => {
        onBack()
      }, 0)
    })
  }

  // onSubmit 提交表单使用
  onSubmit = async () => {
    const { onSubmit } = this.props;
    const result = await this.editForm.validate();
    const hasError = !!result;
    if (hasError) {
      return;
    }
    this.editForm.submit((formData: any, error: Error) => {
      console.log(`error: `, error, `v: `, this.formatOut(formData), '======submit');
      if (error) {
        return;
      }
      this.setState({
        guideVisible: false
      }, () => {
        setTimeout(() => {
          onSubmit(this.formatOut(formData));
        }, 0)
      })
    })
  }

  renderGuide() {
    const { value, guideVisible } = this.state;
    const config = transferStep(this.formatOut(value));
    return <GuidePreview steps={config} visible={guideVisible} />;
  }

  render() {
    const { value } = this.state;
    return (
      <div className="guide-designer-step-detail">
        {this.renderGuide()}
        <div className="guide-designer-step-detail-content">
          <Form ref={(c: any) => {
            if (c) {
              this.editForm = c.getInstance();
            }
          }} onChange={this.onChange} value={value}>
            <SectionHeader title={'位置属性'}></SectionHeader>
            <SelectDomField name="location.element" label="页面元素" required extra="数据渲染的节点会导致运行时匹配失败，可以尝试输入css选择器"></SelectDomField>
            {/* <SelectField name="location.position" label="定位类型" dataSource={[{
                  text: '绝对定位',
                  value: "absolute"
                }, {
                  text: '相对定位',
                  value: "relative"
                }]}></SelectField> */}
            {/* <NumberField name="location.top" label="顶部偏移" defaultValue={200}></NumberField>
                <NumberField name="location.right" label="右侧偏移" ></NumberField>
                <NumberField name="location.bottom" label="底部偏移" ></NumberField>
                <NumberField name="location.left" label="左侧偏移" defaultValue={200}></NumberField> */}
            <SelectField name="location.align" label="气泡框位置" dataSource={alignEnum} defaultValue={'b'}></SelectField>
            {/* <Panel title="样式属性"> */}
            {/* <NumberField name="style.width" label="宽度" defaultValue={200}></NumberField>
                <NumberField name="style.height" label="高度" defaultValue={200}></NumberField> */}
            {/* <TextField name="input1" label="输入框-单行"></TextField> */}
            {/* </Panel> */}
            <SectionHeader title={'画布设置'}></SectionHeader>
            <SelectField required name="canvas.matchRule" label="页面匹配规则" defaultValue={'none'} dataSource={matchRuleEnum} ></SelectField>
            {
              value['canvas.matchRule'] === 'url' &&
              <InputUrlField name="canvas.url" label="页面地址" type='url'></InputUrlField>
            }
            {
              value['canvas.matchRule'] === 'spm' &&
              <InputUrlField name="canvas.spm" label="页面SPM码" type='spm'></InputUrlField>
            }
            <SwitchField
              name="canvas.mask"
              label="遮罩配置"
              defaultValue={false}
            />
            <SectionHeader title={'内容设置'}></SectionHeader>
            <TextField name="content.title" label="标题" ></TextField>
            <TextField name="content.image" label="配图地址" ></TextField>
            <TextField name="content.videoUrl" label="视频地址" ></TextField>
            <TextField name="content.info" htmlType="textarea" label="内容" ></TextField>
            <TextField name="parent" label="滚动父节点" type='url' extra="可不填，当页面滚动元素不是body时需填写"></TextField>
          </Form>
        </div>
        <div className="guide-designer-step-detail-footer">
          <Button
            style={{
              marginRight: 8,
            }}
            onClick={this.onBack}
          >
            返回
          </Button>
          <Button onClick={this.onSubmit} type="primary">
            确定
          </Button>
        </div>
      </div>
    )
  }
}