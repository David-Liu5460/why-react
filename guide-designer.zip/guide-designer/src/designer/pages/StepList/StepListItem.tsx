
import React from "react";
import { Button, Balloon } from "@ali/deep";
import { BaseListItem, BaseListItemProps } from "../../../component/ListItem";

class StepListItem extends BaseListItem {
  constructor(props: BaseListItemProps<any>) {
    super(props);
  }

  renderDelete() {

    const { onDelete, data, index } = this.props;
    const deleteButton = <Button text >删除</Button>
    return (
      <Balloon align="bl" triggerType="click" trigger={deleteButton} closable={false} showButton onOk={() => onDelete(data, index)} popupContainer={(trigger: any) => trigger.parentNode} >
        确认删除么?
      </Balloon>
    )
  }
  renderNormal() {
    const { onEdit, data, index } = this.props;
    const { desc, name } = data;
    return (
      <div className="guide-designer-step-item">
        <div className="guide-designer-step-item-media">
          <span className="guide-designer-step-item-media-index">{index + 1}</span>
        </div>
        <div className="guide-designer-step-item-content">
          <div className="guide-designer-step-item-content-title">{name}</div>
          <div className="guide-designer-step-item-content-desc">{desc}</div>
          <div className="guide-designer-step-item-content-action">
            {/* <Button text>预览</Button> */}
            <Button text onClick={() => onEdit(data)}>编辑</Button>
            {this.renderDelete()}
          </div>
        </div>
      </div>
    )
  }

}

export default StepListItem;