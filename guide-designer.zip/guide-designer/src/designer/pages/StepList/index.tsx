import * as React from "react";
import { v4 as uuid } from "uuid";
import { Button, Balloon, Form, TextField, Illustration, Step, SwitchField } from "@ali/deep";
import ReactDragList from 'react-drag-list'

import StepListItem from "./StepListItem";

import { ScriptSchema, StepSchema } from "../../../types/index";

import "./index.scss"

interface StepListProps {
  onEdit: (data: StepSchema) => void;
  onClose: () => void;
  onBack: () => void;
  data: ScriptSchema,
  onChange: (data: ScriptSchema) => void;
}

export default class StepList extends React.Component<StepListProps> {

  static displayName = 'StepList'

  stepFormRef: typeof Form
  editForm: typeof Form

  state = {
    visible: false
  }

  onStepContentDelete = (values: StepSchema, index: number) => {
    const { data, onChange } = this.props;

    const { props } = data;
    const { script = [] } = props;

    const newScripts = script.slice();

    newScripts.splice(index, 1);
    // 新的剧本
    const newCurrentScript = {
      ...data,
      props: {
        ...data?.props,
        script: newScripts
      }
    };
    onChange(newCurrentScript);
  }

  onStepAdd = async () => {
    const { data, onChange } = this.props;
    const { props } = data;
    const { script = [] } = props;
    const newScripts = script.slice();

    const result = await this.stepFormRef.validate();
    const hasError = !!result;
    if (hasError) {
      return;
    }
    this.stepFormRef.submit((value: any, error?: Error) => {
      if (error) {
        return;
      }
      newScripts.push({
        ...value,
        scriptType: "sandbox",
        _id: uuid(),
        props: {
          canvas: {
            mask: false
          },
          formation: [{
            name: 'card',
            _id: "material_d1f12ecb",
            props: {
              content: {
                title: '我是引导标题',
                info: "我是引导提示"
              }
            }
          }]
        }
      })
      const newCurrentScript = {
        ...data,
        props: {
          ...data?.props,
          script: newScripts
        }
      };
      onChange(newCurrentScript);
      this.handleVisibleChange(false);
    });
  }

  onSortEnd = (newScript: StepSchema[]) => {
    const { data, onChange } = this.props;
    const newCurrentScript: ScriptSchema = {
      ...data,
      props: {
        ...data?.props,
        script: newScript
      }
    };
    onChange(newCurrentScript);
  }

  handleVisibleChange = (visible: boolean) => {
    this.setState({ visible });
  }


  renderButton() {
    const { visible } = this.state;
    const { onBack } = this.props;
    const trigger = <Button type="primary" onClick={() => {
      this.handleVisibleChange(true)
    }}>新建步骤</Button>;
    return (
      <>
        <Button
          style={{
            marginRight: 8,
          }}
          onClick={onBack}
        >
          返回
          </Button>
        <Balloon align="tl" triggerType="click" visible={visible} onVisibleChange={this.handleVisibleChange} trigger={trigger} closable={false} showButton onOk={this.onStepAdd}>
          <div>
            <Form
              wid
              ref={(c: any) => {
                if (c && c.getInstance) {
                  this.stepFormRef = c.getInstance();
                }
              }}
              labelAlign="top"
            >
              <TextField
                name="name"
                label="步骤名称"
                defaultValue="步骤名称"
                maxLength={15}
                hasLimitHint
                required
              />
              <TextField
                name="desc"
                label="步骤描述"
                htmlType="步骤描述"
                maxLength={100}
                hasLimitHint
              />
            </Form>
          </div>
        </Balloon>
      </>
    )
  }

  renderItem = (step: StepSchema) => {
    const { name, desc, _id } = step;
    return <Step.Item status="process" key={_id} title={name} content={desc} />
  }

  renderNode = (index: number) => {
    return <div className="guide-designer-step-node"><span>{index + 1}</span></div>;
  }


  renderStepList() {
    const { data, onEdit } = this.props;
    const { props, name } = data;
    const { script = [] } = props;

    return (
      <div className="guide-designer-step-list">
        <div className="guide-designer-step-list-content">
          {
            script.length > 0
              ?
              // <Step shape="circle" direction='ver' itemRender={this.renderNode}>
              //   {
              //     script.map(step => this.renderItem(step))
              //   }
              // </Step>
              <ReactDragList
                rowKey="_id"
                handles={false}
                onUpdate={(e, updated: any[]) => {
                  this.onSortEnd(updated)
                }}
                dataSource={script.slice()}
                row={(record: Object, index) => <StepListItem data={record} index={index} onEdit={onEdit} onDelete={this.onStepContentDelete} />}
              />
              : <Illustration type="empty" size="small" link="#" content="当前剧本下暂无任何步骤" />
          }

        </div>
        <div className="guide-designer-step-list-footer">
          {this.renderButton()}
        </div>
      </div>
    )
  }

  render() {
    return (
      <>
        {this.renderStepList()}
      </>
    )
  }
}