import * as React from "react";
import { Form, TextField, Button, SectionHeader, SwitchField } from "@ali/deep";
import { v4 as uuid } from "uuid";
import merge from "lodash.merge";
import { formDataFormatIn, formDataFormatOut } from "../../helper";

import { ScriptSchema } from "../../../types/index";
import "./index.scss";

interface ScriptDetailProps {
  data?: ScriptSchema;
  onSubmit: (values: any) => void;
  onBack: () => void;
}

interface ScriptDetailState {
  value: any;
}

export default class ScriptDetail extends React.Component<ScriptDetailProps, ScriptDetailState> {
  static displayName = 'ScriptDetail';

  editForm: any;

  onSubmit = async () => {
    const { onSubmit, onBack, data = {} } = this.props;
    const result = await this.editForm.validate();
    const hasError = !!result;
    if (hasError) {
      return;
    }
    this.editForm.submit((formData: any, error: Error) => {
      if (error) {
        return;
      }
      const formatValue = formDataFormatOut(formData);
      const submitData = merge(data, {
        ...formatValue,
        _id: uuid(),
        scriptType: "real",
      })
      // 只修改name和desc
      onSubmit(submitData)
      setTimeout(onBack)
    })
  }

  render() {
    const { data, onBack } = this.props;
    const result = formDataFormatIn(data);
    console.log(333, result, data);
    return (
      <>
        <div className="guide-designer-content-body guide-designer-script-detail">
          <Form ref={(c: any) => {
            if (c) {
              this.editForm = c.getInstance();
            }
          }} value={result}>
            <SectionHeader title={'基本设置'}></SectionHeader>
            <TextField
              name="name"
              label="剧本名称"
              defaultValue="剧本名称"
              maxLength={30}
              hasLimitHint
              required
            />
            <TextField
              name="desc"
              label="剧本描述"
              htmlType="剧本描述"
              maxLength={100}
              hasLimitHint
            />
            <SectionHeader title={'文案设置'}></SectionHeader>
            <TextField
              name="props.locale.pass"
              label="跳过"
              maxLength={50}
              hasLimitHint
            />
            <TextField
              name="props.locale.prev"
              label="上一步"
              maxLength={50}
              hasLimitHint
            />
            <TextField
              name="props.locale.next"
              label="下一步"
              maxLength={50}
              hasLimitHint
            />
            <TextField
              name="props.locale.finish"
              label="完成"
              maxLength={50}
              hasLimitHint
            />
            <SectionHeader title={'高级设置'}></SectionHeader>
            <SwitchField
              name="props.ignorePassBtn"
              label="禁止步骤跳过"
              defaultValue={false}
            />
          </Form>
        </div>
        <div className="guide-designer-content-footer">
          <Button
            style={{
              marginRight: 8,
            }}
            onClick={onBack}
          >
            返回
          </Button>
          <Button onClick={this.onSubmit} type="primary">
            确定
          </Button>
        </div>
      </>
    )
  }
}