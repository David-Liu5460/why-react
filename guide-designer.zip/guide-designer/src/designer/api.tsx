import React from 'react';
import ReactDOM from 'react-dom';
import { Message } from "@ali/deep";
import { getSchemaListInFuyao, saveSchemaDataJsonpInFuyao, deleteSchemaDataInFuyao, setEnv, setEnvType } from "../service";
import GuideDesigner from "./index";
import { IDeepGuideDesignerProps } from "../types/index";

interface IFuyaoGuideDesignerProps extends IDeepGuideDesignerProps {
  isFuyao: boolean;
  env: 'product' | 'pre' | 'develop';
  workNo?: string;
  isWAN?: boolean
}


const showGuideDesigner = (props: IDeepGuideDesignerProps) => {
  const div = document.createElement('div');
  document.body.appendChild(div);

  const close = () => {
    ReactDOM.unmountComponentAtNode(div);
    if (document.body.contains(div)) {
      document.body.removeChild(div);
    }
  }

  ReactDOM.render(<GuideDesigner {...props} visible={true} />, div);
  return {
    close
  }
}
const showFuyaoGuideDesigner = async (props: IFuyaoGuideDesignerProps) => {
  const { appCode, env, isWAN = false, workNo } = props;
  // FIXME: 改成动态数据
  setEnv(env)
  setEnvType(isWAN ? 'vpc' : "inner");
  const div = document.createElement('div');
  document.body.appendChild(div);

  const isFuyao = !!(props.isFuyao && props.appCode);
  const newProps: IDeepGuideDesignerProps = {
    ...props
  }

  if (isFuyao) {
    const scriptList = await getSchemaListInFuyao({
      appCode,
    }, env);

    newProps.scriptList = (scriptList || []).filter((item) => {
      const { guideType } = item;
      return guideType !== 'dialog';
    }).map((item: any) => {
      const { id, schema } = item;
      schema.id = id;
      return schema;
    })
    // 点击同步后才保存
    newProps.onScriptItemSubmit = async (scriptItem) => {
      const { id, guideType } = scriptItem;
      await saveSchemaDataJsonpInFuyao({
        appCode,
        schema: JSON.stringify(scriptItem),
        id,
        workNo,
        guideType: guideType || "common"
      })
      Message.success('保存成功！');
    }
    newProps.onScriptItemDelete = async (id: string) => {
      await deleteSchemaDataInFuyao({
        id
      })
      Message.success("删除成功！")
    }
  }

  const close = () => {
    ReactDOM.unmountComponentAtNode(div);
    if (document.body.contains(div)) {
      document.body.removeChild(div);
    }
  }

  ReactDOM.render(<GuideDesigner  {...newProps} visible={true} />, div);
  return {
    close
  }
}

export {
  showGuideDesigner,
  showFuyaoGuideDesigner
};