declare module '@ali/boil'
declare module '@ali/fryjs/index'

declare module '@ali/deep/lib/*'

declare module "@ali/deep/lib/user-guide" {
  import { Component } from "react";
  class UserGuide<P = any, S = any> extends Component<P, S> {
    static registerField({ }): void;
    static registerWidget({ }): void;
    static defaultProps: any;
  }

  export default UserGuide;
}

interface Window {
  AliMonitorQueue: any;
  AliMonitor: any;
}