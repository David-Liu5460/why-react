import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { Button, Icon } from '@alifd/next';
import classnames from 'classnames';
import UserGuide from "@ali/deep/lib/user-guide";

import zhCn from '../locale/zh-cn';
import enUs from '../locale/en-us';

class Guide extends Component<any, any> {
  static displayName = 'UserGuideApi';

  static defaultProps = {
    deepPrefix: 'deep-',
    ignorePassBtn: false,
    locale: zhCn,
    currentStep: 0,
  };

  constructor(props: any) {
    super(props);
    this.state = {
      visible: true,
      currentStep: this.props.currentStep || 0,
    };
  }

  hide = () => {
    this.setState({
      visible: false
    })
  }

  next = () => {
    this.props.eventHandlers.onNext(this.state.currentStep);
    this.setState({ currentStep: this.state.currentStep + 1 });
  }

  prev = () => {
    this.props.eventHandlers.onPrev(this.state.currentStep);
    this.setState({ currentStep: this.state.currentStep - 1 });
  }

  finish = (type: 'finish' | 'dismiss' = 'finish') => {
    // 记录所有内容已读，不重复显示
    const { steps, shouldPreventDuplicated } = this.props;
    steps.forEach((step: any) => {
      if (shouldPreventDuplicated) {
        const key = `user-guide-${step.element}`;
        localStorage.setItem(key, '1');
      }
    });
    this.setState({ visible: false });

    if (type === 'finish') {
      this.props.eventHandlers.onFinish(this.state.currentStep);
    } else {
      this.props.eventHandlers.onDismiss(this.state.currentStep);
    }
  }

  renderSteps = () => {
    const { steps } = this.props;
    // 步骤数大于1时才展示几分之几
    if (steps && steps.length > 1) {
      return <span>{this.state.currentStep + 1} / {steps.length} </span>;
    }
    return null;
  }

  render() {
    const { steps, locale, deepPrefix, prefix, ignorePassBtn, className } = this.props;

    if (typeof steps === 'undefined') {
      throw new Error(`[${deepPrefix}user-guide-api] props.steps 必须声明`);
    }

    const current = steps[this.state.currentStep];

    const btnFinish = <Button prefix={prefix} size="small" key="btnFinish" type="primary" onClick={() => this.finish('finish')}>{locale['finish']}</Button>;
    const btnPrev = <Button prefix={prefix} size="small" type="normal" style={{ marginRight: '10px' }} onClick={this.prev}>{locale['prev']}</Button>;
    const btnNext = <Button prefix={prefix} size="small" key="btnNext" type="primary" onClick={this.next}>{locale['next']}</Button>;
    const actions = [];
    if (steps.length > 1) {
      if (this.state.currentStep > 0) {
        actions.push(btnPrev);
      }
      if (this.state.currentStep < steps.length - 1) {
        actions.push(btnNext);
      }
      if (this.state.currentStep === steps.length - 1) {
        actions.push(btnFinish);
      }
    } else {
      actions.push(btnFinish);
    }

    return (
      <UserGuide
        {...current}
        className={className}
        element={current.element}
        visible={this.state.visible}
        deepPrefix={deepPrefix}
        prefix={prefix}
        alignContent={current.alignContent || 'right'}
      >
        <div className={`${deepPrefix}user-guide-api`}>
          {
            current.title ? <h1 className={`${deepPrefix}user-guide-api-title`}>{this.renderSteps()}{current.title}</h1> : null
          }
          {
            current.icon ? <Icon className={`${deepPrefix}user-guide-api-icon`} size="xl" type={current.icon} /> : null
          }
          {
            current.content ? (
              <div
                className={
                  classnames({
                    [`${deepPrefix}user-guide-api-content`]: true,
                    [`${deepPrefix}user-guide-api-content-with-icon`]: typeof current.icon !== 'undefined',
                  })}
              >
                {current.content}
              </div>
            ) : null
          }
          <div className={`${deepPrefix}user-guide-api-action-bar`}>
            {
              !ignorePassBtn &&
              <div className={`${deepPrefix}user-guide-api-step-ancor`}>
                <button className={`${deepPrefix}user-guide-api-btn-pass`} onClick={() => this.finish('dismiss')}>{locale['pass']}</button>
              </div>
            }
            {actions}
          </div>
        </div>
      </UserGuide>
    );
  }
}

const detectWillShow = (steps: any) => {
  // 防重复提示机制，以 user-guide-step.element 为 key 存储入 localStorage
  if (steps.length) {
    const willShow = steps.filter((step: any) => {
      const key = `user-guide-${step.element}`;
      const stepHasShown = localStorage.getItem(key);
      if (stepHasShown) {
        return false;
      } else {
        return true;
      }
    });
    if (willShow.length > 0) {
      return willShow;
    }
  }
  return false;
};

interface TUserGuideStep {
  element: string | HTMLElement;
  title: any;
  content: any;
  icon: string;
  ballonAlign: string;
  mode: 'cover' | 'point';
}

export let renderContainer: HTMLDivElement = undefined;
export let guideRef: Guide = undefined;

export default (
  steps: TUserGuideStep[],
  shouldPreventDuplicated: boolean = false,
  currentStep?: number,
  options?: any
) => {
  const { locale = zhCn, ...others } = options || {};
  let willShow = steps;
  if (shouldPreventDuplicated) {
    willShow = detectWillShow(steps);
  }

  const eventHandlers = {
    onFinish: () => { },
    onPrev: () => { },
    onNext: () => { },
    onDismiss: () => { },
  };

  if (willShow) {
    if (!renderContainer) {
      renderContainer = document.createElement('div');
      document.body.appendChild(renderContainer);
    } else {
      guideRef = undefined;
      ReactDOM.unmountComponentAtNode(renderContainer);
    }
    ReactDOM.render(<Guide steps={willShow} ref={(c) => guideRef = c} currentStep={currentStep} locale={locale} eventHandlers={eventHandlers} shouldPreventDuplicated={shouldPreventDuplicated} {...others} />, renderContainer);
  }

  const ret = {
    onFinish: (cb: any) => { eventHandlers.onFinish = cb; return ret; },
    onPrev: (cb: any) => { eventHandlers.onPrev = cb; return ret; },
    onNext: (cb: any) => { eventHandlers.onNext = cb; return ret; },
    onDismiss: (cb: any) => { eventHandlers.onDismiss = cb; return ret; },
  };
  return ret;
};
