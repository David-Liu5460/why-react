import React from 'react';
import { ConfigProvider, Button, Input, Message } from '@ali/deep';
import BaseField from '@ali/deep/lib/form-helper';
import Uri from "jsuri";
import { getSpm } from "../help";

const InputUrl = (props: any) => {
  const { value, onChange, type } = props;

  const onClick = async () => {
    if (type === 'url') {
      const uri = new Uri(window.location.href);
      const path = uri.setProtocol('').setHost('').toString();
      onChange(path)
    } else if (type === 'spm') {
      const { spma, spmb } = await getSpm();
      if (spma && spmb) {
        onChange(`${spma}.${spmb}`);
        return;
      }
      Message.error("该页面下未找到对应的spm码")
    }
  }

  const button = <Button onClick={onClick}>获取</Button>
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center'
    }}>
      <Input value={value} addonAfter={button} onChange={onChange}></Input>
    </div>
  )
}
class InputUrlField extends BaseField {
  static displayName = 'InputUrlField';

  // 可选实现，无额外属性不需要使用，覆盖时必须混入 BaseField.propTypes
  static propTypes = {
    ...BaseField.propTypes,
  };

  // 可选实现，无额外属性不需要使用，覆盖时必须混入 BaseField.defaultProps
  static defaultProps = {
    ...BaseField.defaultProps,
  };

  // 必须实现，加入具体表单域的样式或其它属性
  getProps() {
    return {
      ...this.props,
      fieldClassName: `${this.props.deepPrefix}input-url-form-field`,
    };
  }
  // 必须实现，具体表单域控件的渲染方法
  renderControl(fieldProps = {}) {

    const InputUrlProps = {
      ...this.getProps(),
      ...fieldProps, // 必须混入 fieldProps
    };

    return <InputUrl {...InputUrlProps} />

  }
}

export default ConfigProvider.config(InputUrlField);
