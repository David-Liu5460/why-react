import React from "react";
import classnames from "classnames";

interface BaseListItemProps<T> {
  data: T;
  className?: string;
  index?: number;
  onEdit?: (data: T) => void;
  onDelete?: (data: T, index?: number) => void;
}

interface BaseListItemState {
  isHover: boolean;
}

class BaseListItem extends React.Component<BaseListItemProps<any>, BaseListItemState> {

  renderNormal() {
    return <div></div>
  }

  render() {
    const { className } = this.props;
    return (
      <div className={classnames('guide-designer-list-item', className)}>
        {this.renderNormal()}
      </div>
    )
  }
}

export {
  BaseListItem,
  BaseListItemProps
}
