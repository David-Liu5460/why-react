import React from "react";
import { ConfigProvider, Button, Input } from "@ali/deep";
import { finder } from "@medv/finder";
import BaseField, { BEHAVIOR } from "@ali/deep/lib/form-helper";

import { initMouseListener } from "../help";

const SelectDom = (props: any) => {
  const { value, onChange } = props;
  const onSelectDom = () => {
    initMouseListener((dom: Element, elFeature: string) => {
      const selector = finder(dom, {
        root: document.body
      });
      onChange(selector);
    });
  };
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
      }}
    >
      <Input value={value} onChange={onChange} addonAfter={<Button onClick={onSelectDom}>选择</Button>} />
    </div>
  );
};
class SelectDomField extends BaseField {
  static displayName = "SelectDomField";

  // 可选实现，无额外属性不需要使用，覆盖时必须混入 BaseField.propTypes
  static propTypes = {
    ...BaseField.propTypes,
  };

  // 可选实现，无额外属性不需要使用，覆盖时必须混入 BaseField.defaultProps
  static defaultProps = {
    ...BaseField.defaultProps,
  };

  // 必须实现，加入具体表单域的样式或其它属性
  getProps() {
    return {
      ...this.props,
      fieldClassName: `${this.props.deepPrefix}xxxx-form-field`,
    };
  }

  // 可选实现，如果输出给开发者的数据格式和 Control 底层数据格式不一致则可以覆盖实现
  // formatValueOut(value, props) { return value; }

  // 可选实现，如果Control 底层需要的数据输入格式和开发者给的数据格式不一致则可以覆盖实现
  // formatValueIn(value, props) { return value; }

  // 可选实现，如果向上抛出的 onChange 事件的参数除了 value 还有其它数据时可以覆盖实现
  /*
  onChange: (value, evt) => {
    const formattedValue = this.formatValueOut(value, this.props);
    this.setValueOnChange(formattedValue);

    this.handleChange({
      value: formattedValue,
      actionType: 'change',
    }, evt);
  },
  */
  // 必须实现，具体表单域控件的渲染方法
  renderControl(fieldProps = {}) {
    const { behavior } = this.state;

    const selectDomProps = {
      readOnly: behavior === BEHAVIOR.READONLY, // 如果支持 readOnly 属性
      ...fieldProps, // 必须混入 fieldProps
    };

    return <SelectDom {...selectDomProps} />;
  }
}

export default ConfigProvider.config(SelectDomField);
