// for designer 用
import React, { Component } from 'react';
import { Icon, Button } from '@ali/deep';

import UserGuide from "@ali/deep/lib/user-guide";

import classnames from 'classnames';

import zhCn from '../locale/zh-cn';
import enUs from '../locale/en-us';

// declare class UserGuide extends React.Component {
// }
// 继承原有的引导之后放出滚动事件
class UserGuideDisplay extends UserGuide {
  wheelListener() {
  }
}

class GuidePreview extends Component<any, any> {
  static displayName = 'UserGuideApi';

  static defaultProps = {
    deepPrefix: 'deep-',
    ignorePassBtn: false,
    locale: zhCn,
  };

  constructor(props: any) {
    super(props);
    this.state = {
      visible: true,
      currentStep: this.props.currentStep || 0,
    };
  }

  next = () => {
    this.props.eventHandlers?.onNext(this.state.currentStep);
    this.setState({ currentStep: this.state.currentStep + 1 });
  }

  prev = () => {
    this.props.eventHandlers?.onPrev(this.state.currentStep);
    this.setState({ currentStep: this.state.currentStep - 1 });
  }

  finish = (type: 'finish' | 'dismiss' = 'finish') => {
    // 记录所有内容已读，不重复显示
    const { steps, shouldPreventDuplicated } = this.props;
    steps.forEach((step: any) => {
      if (shouldPreventDuplicated) {
        const key = `user-guide-${step.element}`;
        localStorage.setItem(key, '1');
      }
    });
    this.setState({ visible: false });

    if (type === 'finish') {
      this.props.eventHandlers?.onFinish(this.state.currentStep);
    } else {
      this.props.eventHandlers?.onDismiss(this.state.currentStep);
    }
  }

  renderSteps = () => {
    const { steps } = this.props;
    if (steps && steps.length > 0) {
      return <span>{this.state.currentStep + 1} / {steps.length} </span>;
    }
    return null;
  }

  render() {
    const { steps, locale, deepPrefix, prefix, ignorePassBtn } = this.props;

    if (typeof steps === 'undefined') {
      throw new Error(`[${deepPrefix}user-guide-api] props.steps 必须声明`);
    }

    const current = steps[this.state.currentStep];

    const btnFinish = <Button prefix={prefix} size="small" key="btnFinish" type="primary" onClick={() => this.finish('finish')}>{locale['finish']}</Button>;
    const btnPrev = <Button prefix={prefix} size="small" type="normal" style={{ marginRight: '10px' }} onClick={this.prev}>{locale['prev']}</Button>;
    const btnNext = <Button prefix={prefix} size="small" key="btnNext" type="primary" onClick={this.next}>{locale['next']}</Button>;
    const actions = [];
    if (steps.length > 1) {
      if (this.state.currentStep > 0) {
        actions.push(btnPrev);
      }
      if (this.state.currentStep < steps.length - 1) {
        actions.push(btnNext);
      }
      if (this.state.currentStep === steps.length - 1) {
        actions.push(btnFinish);
      }
    } else {
      actions.push(btnFinish);
    }

    return (
      <UserGuide
        {...current}
        element={current.element}
        visible={this.state.visible}
        deepPrefix={deepPrefix}
        prefix={prefix}
        alignContent={current.alignContent || 'right'}
      >
        <div className={`${deepPrefix}user-guide-api`}>
          {
            current.title ? <h1 className={`${deepPrefix}user-guide-api-title`}>{this.renderSteps()}{current.title}</h1> : null
          }
          {
            current.icon ? <Icon className={`${deepPrefix}user-guide-api-icon`} size="xl" type={current.icon} /> : null
          }
          {
            current.content ? (
              <div
                className={
                  classnames({
                    [`${deepPrefix}user-guide-api-content`]: true,
                    [`${deepPrefix}user-guide-api-content-with-icon`]: typeof current.icon !== 'undefined',
                  })}
              >
                {current.content}
              </div>
            ) : null
          }
          <div className={`${deepPrefix}user-guide-api-action-bar`}>
            {
              !ignorePassBtn &&
              <div className={`${deepPrefix}user-guide-api-step-ancor`}>
                <button className={`${deepPrefix}user-guide-api-btn-pass`} onClick={() => this.finish('dismiss')}>{locale['pass']}</button>
              </div>
            }
            {actions}
          </div>
        </div>
      </UserGuide>
    );
  }
}


export default GuidePreview;