import React from "react";
export default function (props: any) {
  return <h2>{props.title || props.children}</h2>
}