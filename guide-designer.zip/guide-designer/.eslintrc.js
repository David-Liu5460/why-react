const { tslint, deepmerge } = require('@ice/spec');

module.exports = deepmerge(tslint, {
  rules: {
    'react/jsx-filename-extension': 'off',
    '@typescript-eslint/no-explicit-any': 'off',
    '@typescript-eslint/explicit-function-return-type': 'off',
    'react/require-default-props': 'off',
    "@typescript-eslint/explicit-member-accessibility": "off",
    'no-underscore-dangle': 'off'
  },
});
